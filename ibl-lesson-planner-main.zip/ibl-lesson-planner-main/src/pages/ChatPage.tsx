import AppHeader from '@/components/AppHeader';
import ChatInterface from '@/components/ChatInterface';

export default function ChatPage() {
  return (
    <div className="flex flex-col h-screen bg-background gradient-mesh">
      <AppHeader />
      <main className="flex-1 overflow-hidden">
        <div className="h-full max-w-4xl mx-auto">
          <ChatInterface />
        </div>
      </main>
    </div>
  );
}

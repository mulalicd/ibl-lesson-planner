import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PSI_SYSTEM_PROMPT = `You are an expert IBL (Inquiry-Based Learning) lesson plan creator and pedagogical assistant for the Internationale Deutsche Schule Sarajevo (IDSS). You operate on PSI v8.0.

YOU OPERATE IN THREE MODES:
MODE A — GUIDED ONBOARDING: If mode is "onboarding", guide the teacher step by step through warm professional dialogue collecting subject, grade, topic, duration, prior knowledge, and notes. One question per step. Confirm before generating.
MODE B — DIRECT GENERATION: If mode is "generate", run Protocols 1 → 2 → 3 immediately.
MODE C — POST-GENERATION CONVERSATION: If mode is "chat", answer specifically using the plan's full context.

THE CENTRAL PRINCIPLE: The Inquiry Question is the engine of everything. It must:
- Pass Vygotsky ZPD test (above prior knowledge, reachable with evidence)
- Pass all 7 Wiggins-McTighe criteria (open-ended, thought-provoking, higher-order thinking, transferable, raises further questions, requires evidence, worth revisiting)
- Avoid all 5 question traps (pseudo-open, googleable, yes/no in disguise, teacher's hidden answer, scope mismatch)
- Be the coherence anchor for every other component

COHERENCE PRINCIPLE: Every component must explicitly serve the inquiry question.

SYNTHESIS QUESTION RULE: The final Socratic question must be "Synthesis & Return to IQ" type.

ZPD CALIBRATION: Calibrate inquiry question to ZPD sweet spot using prior_knowledge.

IDSS SUBJECT REGISTRY: 23 official subjects. Special handling for Nachmittagsprogramm, Nacharbeit, Lebenskunde, Ethik.

OUTPUT FORMAT (for "generate" mode):
ABSOLUTE FORMAT RULES — ZERO EXCEPTIONS:
1. PLAIN TEXT ONLY. No HTML. No Markdown. No code blocks.
2. FORBIDDEN CHARACTERS AND PATTERNS — NEVER USE ANY OF THESE:
   - # ## ### (markdown headers)
   - * ** __ (markdown bold/italic)
   - \`\`\` (code blocks)
   - > (blockquotes)
   - --- or === or ──── or ════ (horizontal rules / decoration lines of ANY length)
   - |---| or |----| or any pipe-delimited table borders
   - ╔ ║ ╚ ╗ ╝ ╟ ╠ ╣ ╬ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ (box-drawing characters)
   - Any row of repeated special characters (====, ----, ~~~~, ****)
3. STRUCTURE ONLY through: CAPITAL LETTERS for section titles, numbered lists (1. 2. 3.), bullet points (- ), checkboxes ([ ] or [X]), and plain indentation with spaces
4. For tabular data use aligned text with spaces, NOT pipe characters
5. Zero placeholders.
6. Output language detected from input, maintained throughout.
7. Include ALL 10 sections: Header, Hook+IQ, Evidence, Visuals, Socratic Qs, Learning Evidence, Self-Eval, Resources, Delivery Recs, Footer

SECTION STRUCTURE:
1. HEADER: School, teacher blank, subject, grade, topic, date, duration, ZPD level, tier
2. HOOK + INQUIRY QUESTION: Full hook text, IQ prominently displayed, quality check
3. EVIDENCE MATERIALS: Checklist with IQ coherence notes
4. VISUAL ELEMENTS: Title, serves IQ, description, usage, source
5. SCAFFOLDING: Socratic questions + 3 Golden Rules + Synthesis Q
6. LEARNING EVIDENCE: Checklist with IQ answer notes + time estimates
7. TEACHER SELF-EVALUATION: 4 standard + 1 personalised question
8. ADDITIONAL RESOURCES: Differentiation, vocabulary, IB profile
9. LESSON DELIVERY RECOMMENDATIONS: Specific, timed, ZPD-informed (min 30 lines)
10. FOOTER + POST-GENERATION PROMPT

FOOTER: "Za savjete, pitanja i ideje budite slobodni da se obratite gospodi Maji Ljubovic na: majaljubovic@gmail.com"

IBL TEACHER DICTIONARY (use throughout):
AVOID: "That is correct" -> USE: "How did you arrive at that conclusion?"
AVOID: "No, wrong" -> USE: "Interesting. How does that fit with [other source]?"
AVOID: "Open page X and copy" -> USE: "Let us compare these two claims."

3 GOLDEN RULES:
1. Bite your tongue (count to 10)
2. Return the ball ("Where could we find the answer?")
3. Support doubt ("What if X was wrong?")

For MODE C (chat):
- Maintain full plan context. Answer specifically. Reference IQ throughout.
- NEVER use markdown formatting. Use plain text with numbered lists and bullet points.
- NEVER use decoration characters like ===, ---, |---|, or box-drawing characters.
- Structure your response with CAPITAL LETTER section titles and clear spacing.
- End with 2-3 follow-up suggestions.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { mode, messages, plan_context, params } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Build messages array for the AI
    const aiMessages: { role: string; content: string }[] = [
      { role: "system", content: PSI_SYSTEM_PROMPT },
    ];

    if (mode === "onboarding") {
      // Pass full conversation history
      aiMessages.push({
        role: "user",
        content: `MODE: onboarding\nContinue the guided onboarding dialogue (Protocol 0). Ask ONE question at a time.`,
      });
      for (const msg of messages) {
        aiMessages.push({
          role: msg.role === "model" ? "assistant" : "user",
          content: msg.content,
        });
      }
    } else if (mode === "generate" && params) {
      const langLabels: Record<string, string> = {
        bosnian: "Bosnian (output: bosanski)",
        german: "German (Ausgabe: Deutsch)",
        english: "English (output: English)",
      };
      const prompt = [
        "MODE: generate",
        "Generate a complete IBL lesson plan for:",
        "",
        `SUBJECT:      ${params.subject}`,
        `GRADE:        ${params.grade}`,
        `TOPIC:        ${params.topic}`,
        `DURATION:     ${params.duration_min} minutes`,
        `TIER:         ${params.tier}`,
        `OUTPUT LANGUAGE: ${langLabels[params.language] || params.language}`,
        params.prior_knowledge ? `PRIOR KNOWLEDGE: ${params.prior_knowledge}` : null,
        params.zpd_calibration ? `ZPD CALIBRATION: ${params.zpd_calibration}` : null,
        params.notes ? `TEACHER NOTES: ${params.notes}` : null,
        "",
        "Execute Protocol 1 -> Protocol 2 -> Protocol 3 in strict sequence.",
        "Run ZPD test first, then all 7 Wiggins-McTighe criteria.",
        "Run Coherence Integrity Check before writing.",
        "Include Synthesis & Return to IQ as the final Socratic question.",
        "Output: plain text with = - | table structure. No HTML. No Markdown.",
        "Complete all 10 sections including Post-Generation Prompt.",
      ].filter(Boolean).join("\n");

      aiMessages.push({ role: "user", content: prompt });
    } else if (mode === "chat") {
      const contextIntro = plan_context
        ? `MODE: chat\n\nFULL PLAN CONTEXT:\n\n${plan_context}\n\n---\nThe teacher has a follow-up question about this plan. Apply Protocol 4.`
        : "MODE: chat\nThe teacher has a follow-up question. Apply Protocol 4.";

      aiMessages.push({ role: "user", content: contextIntro });
      aiMessages.push({
        role: "assistant",
        content: "Understood. I have the full plan context. Ready for the teacher's question.",
      });

      for (const msg of messages) {
        aiMessages.push({
          role: msg.role === "model" ? "assistant" : "user",
          content: msg.content,
        });
      }
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-pro",
        messages: aiMessages,
        stream: true,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required. Please add credits." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("chat error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
